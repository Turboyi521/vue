import attrs from './attrs'
import domProps from './dom-props'
import klass from './class'
import style from './style'

export default [
  attrs,
  domProps,
  klass,
  style
]

<!--
IMPORTANT: Please use the following link to create a new issue:

  https://new-issue.vuejs.org/

If your issue was not created using the app above, it will be closed immediately.

中文用户请注意：
请使用上面的链接来创建新的 issue。如果不是用上述工具创建的 issue 会被自动关闭。
-->

<!--
Love vuejs? Please consider supporting us via Patreon or OpenCollective:
👉  https://www.patreon.com/evanyou
👉  https://opencollective.com/vuejs/donate
-->
